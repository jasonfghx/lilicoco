from flask import render_template,Flask,request,redirect,url_for ,flash,jsonify,json, send_file,session
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_sqlalchemy import SQLAlchemy
import sqlite3
import pandas as pd
app = Flask(__name__)
app.config['SECRET_KEY'] = 'super secret key'


@app.route("/")
def home1():
    return render_template('home.html',**locals())
@app.route("/h")
@login_required
def home():
    USR = current_user.get_id()
    try:

        sql_select='''SELECT * FROM member where TEL='{}' '''.format(USR)
        data2=pd.read_sql_query(sql_select,conn)  
        name=data2['name1'][0]
        mail=data2['mail'][0]
        tel=data2['TEL'][0]
    except:
        Exception

    return render_template('main.html',**locals())
@app.route("/add",methods=["GET",'POST'])
@login_required
def meal_add():
    db.create_all()
    if request.method=='POST':
        try:
            Am= request.values['Am']
        except:
            Am=''
        try:
            Bm= request.values['Bm']
        except:
            Bm=''
        try:
            Cm= request.values['Cm']
        except:
            Cm=''
        try:
            Dm= request.values['Dm']
        except:
            Dm=''
        try:
            Em= request.values['Em']
        except:
            Em=''
        try:
            Fm= request.values['Fm']
        except:
            Fm=''
        try:
            Gm= request.values['Gm']
        except:
            Gm=''
        try:
            Hm= request.values['Hm']
        except:
            Hm=''
        try:
            final= request.values['final']
        except:
            final=''
        try:
            fina2= request.values['fina2']
        except:
            fina2=''
        meal=Am+'/'+Bm+'/'+Cm+'/'+Dm+'/'+Em+'/'+Fm+'/'+Gm+'/'+Hm
        if final=='':
            address=fina2
        else:
            address=final
        d= request.values['time']
        # print(meal,address),
        add_data = mealDB(meal=meal,address=address,d=d)
        try:
            db.session.add(add_data)
            db.session.commit()
            db.session.close()
        except Exception as e:
            print(e)
            # Exception

    return render_template('main.html')
@app.route("/meal_show")
def meal_show():
    conn=sqlite3.connect("DB/meal.db")
    sql_select='''SELECT * FROM meal '''
    data2=pd.read_sql_query(sql_select,conn)   
    data2html=data2.to_html(index=False)
    return data2html
@app.route("/member_show")
def member_show():
    conn=sqlite3.connect("DB/meal.db")
    sql_select='''SELECT * FROM member '''
    data2=pd.read_sql_query(sql_select,conn)   
    data2html=data2.to_html(index=False)
    return data2html
@app.route('/logout')
def logout():
    USR = current_user.get_id()
    logout_user()
    if USR is None:
        USR=''
    flash(f'{USR} 登出')
    return render_template('login.html')

if __name__ == '__main__':
  app.debug = True
  app.run(host="127.0.0.1",port=5005,debug=True)#